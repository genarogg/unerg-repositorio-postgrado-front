"use client"
import type React from "react"
import SelectFilters from "./SelectFilters"

type FiltersProps = {}

const Filters: React.FC<FiltersProps> = () => {
  return (
    <>
      <SelectFilters />
    </>
  )
}

export default Filters
