"use client"
import type React from "react"
import { useState } from "react"
import { Input, CheckboxGroup } from "../ux"
import {
  Settings,
  Database,
  BookOpen,
  FileText,
  Calendar,
} from "lucide-react"
import "./reportes.css"

// Tipos para la configuración del reporte
interface ReportConfig {
  name: string
  description: string
  entities: string[]
  selectedLineas: string[]
  selectedPeriodos: string[]
}

// Configuración de entidades y campos disponibles
const ENTITIES_CONFIG = {
  lineasInvestigacion: {
    label: "Líneas de Investigación",
    icon: <BookOpen size={16} />,
    fields: {
      id: { label: "ID", type: "number" },
      nombre: { label: "Nombre", type: "string" },
      estado: { label: "Estado", type: "boolean" },
      usuarioId: { label: "Usuario ID", type: "number" },
      "usuario.name": { label: "Nombre Usuario", type: "string" },
      "usuario.email": { label: "Email Usuario", type: "string" },
    },
  },
  trabajos: {
    label: "Trabajos",
    icon: <FileText size={16} />,
    fields: {
      id: { label: "ID", type: "number" },
      titulo: { label: "Título", type: "string" },
      autor: { label: "Autor", type: "string" },
      estado: { label: "Estado", type: "enum", options: ["PENDIENTE", "VALIDADO", "RECHAZADO"] },
      resumen: { label: "Resumen", type: "text" },
      lineaDeInvestigacionId: { label: "Línea de Investigación ID", type: "number" },
      "lineaDeInvestigacion.nombre": { label: "Línea de Investigación", type: "string" },
      periodoAcademicoId: { label: "Período Académico ID", type: "number" },
      "periodoAcademico.periodo": { label: "Período Académico", type: "string" },
    },
  },
  periodosAcademicos: {
    label: "Períodos Académicos",
    icon: <Calendar size={16} />,
    fields: {
      id: { label: "ID", type: "number" },
      periodo: { label: "Período", type: "string" },
    },
  },
}

const ConfiguracionReporte: React.FC = () => {
  const [reportConfig, setReportConfig] = useState<ReportConfig>({
    name: "",
    description: "",
    entities: [],
    selectedLineas: [],
    selectedPeriodos: [],
  })

  // Opciones simuladas para líneas de investigación
  const lineasOptions = [
    { id: "1", label: "Inteligencia Artificial", description: "Investigación en IA y Machine Learning" },
    { id: "2", label: "Ciencia de Datos", description: "Análisis y procesamiento de datos" },
    { id: "3", label: "Desarrollo Web", description: "Tecnologías web y aplicaciones" },
    { id: "4", label: "Ciberseguridad", description: "Seguridad informática y protección de datos" },
    { id: "5", label: "Realidad Virtual", description: "Tecnologías inmersivas y VR/AR" },
  ]

  // Opciones simuladas para períodos académicos
  const periodosOptions = [
    { id: "2024-1", label: "2024-1", description: "Primer semestre 2024" },
    { id: "2024-2", label: "2024-2", description: "Segundo semestre 2024" },
    { id: "2023-1", label: "2023-1", description: "Primer semestre 2023" },
    { id: "2023-2", label: "2023-2", description: "Segundo semestre 2023" },
    { id: "2022-1", label: "2022-1", description: "Primer semestre 2022" },
  ]

  // Opciones para selección de entidades
  const entityOptions = Object.entries(ENTITIES_CONFIG).map(([key, config]) => ({
    id: key,
    label: config.label,
    description: `Incluir datos de ${config.label.toLowerCase()}`,
  }))

  // Manejar cambios en la configuración
  const handleConfigChange = (key: keyof ReportConfig, value: any) => {
    setReportConfig((prev) => ({
      ...prev,
      [key]: value,
    }))
  }

  return (
    <div className="report-config-section">
      <div className="config-grid">
        {/* Información básica */}
       

        {/* Líneas de Investigación */}
        <div className="config-card">
          <div className="config-card-header">
            <BookOpen size={20} />
            <h3>Líneas de Investigación</h3>
          </div>
          <div className="config-card-content">
            <CheckboxGroup
              title="Selecciona las líneas de investigación"
              subtitle="Elige qué líneas de investigación incluir en tu reporte"
              options={lineasOptions}
              selectedValues={reportConfig.selectedLineas}
              onChange={(values) => handleConfigChange("selectedLineas", values)}
              allowMultiple={true}
              showSelectAll={true}
            />
          </div>
        </div>

        {/* Períodos Académicos */}
        <div className="config-card">
          <div className="config-card-header">
            <Calendar size={20} />
            <h3>Períodos Académicos</h3>
          </div>
          <div className="config-card-content">
            <CheckboxGroup
              title="Selecciona los períodos académicos"
              subtitle="Elige qué períodos académicos incluir en tu reporte"
              options={periodosOptions}
              selectedValues={reportConfig.selectedPeriodos}
              onChange={(values) => handleConfigChange("selectedPeriodos", values)}
              allowMultiple={true}
              showSelectAll={true}
            />
          </div>
        </div>
      </div>
    </div>
  )
}

export default ConfiguracionReporte