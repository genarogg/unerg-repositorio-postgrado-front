'use client'
import React from 'react'
import UsuarioTabla from '../usuarios'

interface exampleV0Props {

}

const exampleV0: React.FC<exampleV0Props> = () => {
    return (
        <UsuarioTabla></UsuarioTabla>
    );
}

export default exampleV0;