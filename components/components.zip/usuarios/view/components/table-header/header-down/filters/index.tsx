"use client"
import type React from "react"

type FiltersProps = {}

const Filters: React.FC<FiltersProps> = () => {
  return null // No hay filtros
}

export default Filters
